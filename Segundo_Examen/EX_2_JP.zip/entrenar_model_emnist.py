import tensorflow as tf
from tensorflow.keras import layers, models
import tensorflow_datasets as tfds

# Cargar el dataset EMNIST Balanced usando tensorflow_datasets
def load_emnist():
    dataset, info = tfds.load("emnist/balanced", split=['train', 'test'], as_supervised=True)
    train_data, test_data = dataset[0], dataset[1]

    def format_data(image, label):
        image = tf.cast(image, tf.float32) / 255.0  # Normalizar las imágenes
        image = tf.expand_dims(image, -1)  # Asegurarse de que las imágenes tengan la dimensión correcta (28, 28, 1)
        return image, label

    train_data = train_data.map(format_data).batch(128).shuffle(10000)
    test_data = test_data.map(format_data).batch(128)

    return train_data, test_data

# Definir el modelo
def create_model():
    model = models.Sequential([
        layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(47, activation='softmax')  # 47 clases en EMNIST Balanced
    ])
    
    model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model

# Cargar los datos
train_data, test_data = load_emnist()

# Crear el modelo
model = create_model()

# Entrenar el modelo
model.fit(train_data, epochs=10, validation_data=test_data)

# Evaluar el modelo en el conjunto de prueba
test_loss, test_acc = model.evaluate(test_data)
print(f'Accuracy en el conjunto de prueba: {test_acc}')
